# Message Translations

This package contains a message translation node and a set of old message conversion methods.
It allows to run applications that are compiled with one set of message versions against a PX4 with another set of message versions, without having to change either the application or the PX4 side.

For details, see https://docs.px4.io/main/en/ros2/px4_ros2_msg_translation_node.html.
